


source("main.R")

####simulation
dat <- simdatbay(n=1000,p=c(0.2,0.3,0.5),theta1=c(100,30,20),theta2=c(10,50,100))

ret <- gibbsskellam(dat=dat,k=3,niter=200,g = 2)

DIC1 <- c()
for(i in 2:5){
  ret <- gibbsskellam(dat=dat,k=i,niter=200,g = 2)
  DIC1 <- c(DIC1,ret$DIC)
}


####work

dat1 <- read.csv("/home/lbjiang/文档/Gene_expressed.csv")
dat11 <- cbind(as.integer(dat1[,2]),as.integer(dat1[,3]),as.integer(dat1[,2]-dat1[,3]))
dat12 <- dat11[index <- which(abs(dat11[,3])<50),]

ret1 <- gibbsskellam(dat=dat12,k=3,niter=200,g = 2)


DIC2<- c()
for(i in 2:4){
  ret2 <- gibbsskellam(dat=dat,k=i,niter=200,g = 2)
  if(is.na(ret2$DIC)){
    ret2 <- gibbsskellam(dat=dat,k=i,niter=200,g = 2)
  }
  DIC2 <- c(DIC2,ret2$DIC)
}



colMeans(ret1$p[100:200,]);colMeans(ret1$theta1[100:200,]);colMeans(ret1$theta2[100:200,]);
apply(ret$theta2[100:200,],2,sd)
