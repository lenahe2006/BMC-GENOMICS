
propost <- function(dat,init){
  
  kk <- dim(init)[1]
  n <- dim(dat)[1]
  allcond <- c()
  for(i in 1:kk){
    
    ktmp <- init[i,1]*dskellam(dat[,3],init[i,2],init[i,3])
    allcond <- cbind(allcond,ktmp)
  }
  
  map <- unlist(apply(allcond, 1, function(x) which(x == max(x, 
                                                             na.rm = TRUE))[1]))
  L <- 0  
  for(i in 1:kk){
    index <- which(map==i)
    if(length(index)==0)
      next
    dt <- dskellam(dat[index,3],init[i,2],init[i,3])
    index.z <- which(dt==0)
    if(length(index.z)>0)
      dt[index.z] <- 1e-360
    L <- L + sum(-log(dt))
  }
  LL <- 2*L
  return(list(map=map,L=LL))
}
gibbsskellam <- function (dat,k,niter,g = 2)
{
  rigamma <- function(n,a,b) {
    return(1/rgamma(n, shape = a, rate = b))
  }
  rdirichlet <- function(n, par) {
    k=length (par)
    z = array(0 , dim=c(n,k))
    s = array(0, dim = c(n,1))
    for (i in 1:k) {
      z[,i] = rgamma(n, shape = par [i])
      s = s + z[,i]
    }
    for (i in 1:k) {
      z[,i] = z[,i]/s
    }
    return(z)
  }
  n <- dim(dat)[1] 
  x <- dat[,3]
  theta1 <- rgamma(k,1,1)#1,1
  theta2 <- rgamma(k,1.01,1.01)#1.01,1.01
  pn <- rep(g,k)
  p <- rdirichlet(1, pn)
  mixparam <- list(p = p, theta1=theta1,theta2=theta2)
  ztmp <- rep(0, k)
  temp <- ztmp
  tempv <- temp
  tempu <- temp
  nj <- ztmp
  theta1j <- ztmp
  theta2j <- ztmp
  gibbstheta1 <- matrix(0, nrow = niter, ncol = k)
  gibbstheta2 <- matrix(0, nrow = niter, ncol = k)
  gibbsp <- gibbstheta1
  LLT <- c()
  for (i in 1:niter) {
    for (t in 1:n) {
      prob <- mixparam$p * dskellam(x[t],lambda1 = mixparam$theta1,
                                    lambda2 = mixparam$theta2)
      ztmp[t] <- sample(x = 1:k, size = 1, prob = prob)
    }
    for (j in 1:k) {
      nj[j] <- sum(ztmp == j)
    }
    nj[which(nj==0)]=1
    gibbsp[i, ] <- rdirichlet(1, par = nj + g)
    mixparam$p <- gibbsp[i,]
    dataj=dat
    for (m in 1:n) {
      for (j in 1:k) {
        temp[j] <- sum(ztmp[m] == j)
      }
      index <- which(temp==1)
      if (x[m] < 0) {
        newv <- rpois(1,lambda=mixparam$theta1[index])
        newu <- newv - x[m]
        alpha <- min(1,(mixparam$theta2[index])^(newv-dat[m,1])
                     *((gamma(dat[m,1]-x[m]+1))/(gamma(newv-x[m]+1))))
        if (runif(1) < alpha){
          dataj[m,1] <- newv
          dataj[m,2] <- newu
        }  
      }
      else {
        newu <- rpois(1,lambda=mixparam$theta2[index])
        newv <- newu + x[m]
        alpha <- min(1,(mixparam$theta1[index])^(newu-dat[m,2])
                     *((gamma(dat[m,2]+x[m]+1))/(gamma(newu+x[m]+1))))
        if (runif(1) < alpha){
          dataj[m,1] <- newv
          dataj[m,2] <- newu
        }  
      }
    }
    
    for (j in 1:k) {
      index1 <- which(ztmp == j)
      tempv[j] <- mean(dataj[index1,1])
      tempv[which(tempv=='NaN')] <- mean(dataj[,1])
      repeat {
        theta1[j] <- rgamma(1,nj[j]*tempv[j]+g,nj[j]+g)
        if (theta1[j] < max(dataj[,1]) & theta1[j] > min(dataj[,1]))
          break
      }
      tempu[j] <- mean(dataj[index1,2])
      tempu[which(tempu=='NaN')] <- mean(dataj[,2])
      repeat {
        theta2[j] <- rgamma(1,nj[j]*tempu[j]+g,nj[j]+g)
        if (theta2[j] < max(dataj[,2]) & theta2[j] > min(dataj[,2]))
          break
      }
    }
    gibbstheta1[i,] <- theta1
    gibbstheta2[i,] <- theta2
    mixparam$theta1 <- theta1
    mixparam$theta2 <- theta2
    
    LL <- propost(dat,init=cbind( mixparam$p,mixparam$theta1,mixparam$theta2))
    cat("round=", i," \n")
    LLT <- c(LLT,LL$L)
  }
  DIC <- var(LLT[100:200],na.rm=T)/2+mean(LLT[100:200],na.rm = T)
  ret <- list(p = gibbsp, theta1 = gibbstheta1, theta2 = gibbstheta2,DIC=DIC,map=LL$map)
  return(ret)
}

fplot.single_para<-function( data,ytitle,xtitle )
{
  n.row <- length(data);
  ylim <- c( min(data)+0.2, max(data)*1.5)
  
  plot( c(0,0), c(0,0), type="n", xaxt="n", yaxt="s", yaxs="i", 
        frame=T, xlab=xtitle, ylab=ytitle, xlim=c(0, n.row+2), ylim=ylim );
  
  xlim <- c(0, length(data));
  nB <- length(data);
  paras <- c(1:nB);
  
  rect(paras, 0, paras+1, data,  col = 2, border =2);
}                        

simdatbay <- function(n,p,theta1,theta2){
  nn <- n*p
  npara1 <- length(theta1)
  z1 <- c()
  z2 <- c()
  z <- c()
  for(i in 1:npara1){
    R1 <- rpois(nn[i],theta1[i])
    R2 <- rpois(nn[i],theta2[i])
    R <- R1 - R2
    z1 <- c(z1,R1)
    z2 <- c(z2,R2)
    z <- c(z,R)
  }
  temp <- cbind(z1,z2,z)
  ns <- sample(1:n,n)
  ret <- temp[ns,]
  return(ret)
}  